from BrickPi import *                                                                   #import BrickPi.py file to use BrickPi operations

def Touch(port):
	result = BrickPiUpdateValues()  # Ask BrickPi to update values for sensors/motors 
        if not result :
                button_value = BrickPi.Sensor[port]
                if button_value > 1000:
#                        print "Button prressed: "+str(button_value)
			 return 1
                else:
#                        print "released: " + str(button_value)
			 return 0
def DriveMotors(port1,port2,power1,power2):
    BrickPi.MotorSpeed[port1] = power1  #Set the speed of MotorB (-255 to 255)
    BrickPi.MotorSpeed[port2] = power2  #Set the speed of MotorA (-255 to 255)

def MoveDegrees(port1,port2,power,degrees):
	val = BrickPi.Encoder[PORT_C]
	initval = val
	target = degrees + BrickPi.Encoder[PORT_C]
	done = 0
	while done != 1:
		if target < initval:
			if val < target:
				done = 1
		else:
			if val > target:
				done = 1
	        BrickPi.MotorSpeed[port1] = power  #Set the speed of MotorB (-255 to 255)
	        BrickPi.MotorSpeed[port2] = power  #Set the speed of MotorA (-255 to 255)
	DriveStop()
def DriveStop(port1, port2):
        BrickPi.MotorSpeed[port1] = 0  #Set the speed of MotorB (-255 to 255)
        BrickPi.MotorSpeed[port2] = 0  #Set the speed of MotorA (-255 to 255)
