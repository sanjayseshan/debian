#ifndef CONFIG_H_IN
#define CONFIG_H_IN

#define HAVE_MYSOFA 1
/* #undef HAVE_MIT_HRTF */

#endif // CONFIG_H_IN
