var searchData=
[
  ['decoder_20related_20ctls',['Decoder related CTLs',['../group__opus__decoderctls.html',1,'']]]
];
