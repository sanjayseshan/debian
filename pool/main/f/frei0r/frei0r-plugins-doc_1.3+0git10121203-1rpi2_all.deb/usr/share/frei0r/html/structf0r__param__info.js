var structf0r__param__info =
[
    [ "explanation", "structf0r__param__info.html#a234708bd246ba2f8aa94c6e556110cac", null ],
    [ "name", "structf0r__param__info.html#aff206a2bd55ec0a5f38f134a9bfa9a66", null ],
    [ "type", "structf0r__param__info.html#a9cff757f4e45b1235e8977a83bd1f70a", null ]
];