var modules =
[
    [ "Plugin Locations", "group__pluglocations.html", null ],
    [ "Icons for frei0r effects", "group__icons.html", null ],
    [ "Concurrency", "group__concurrency.html", null ],
    [ "Type of the Plugin", "group___p_l_u_g_i_n___t_y_p_e.html", "group___p_l_u_g_i_n___t_y_p_e" ],
    [ "Color Models", "group___c_o_l_o_r___m_o_d_e_l.html", "group___c_o_l_o_r___m_o_d_e_l" ],
    [ "Parameter Types", "group___p_a_r_a_m___t_y_p_e.html", "group___p_a_r_a_m___t_y_p_e" ]
];