var group___c_o_l_o_r___m_o_d_e_l =
[
    [ "F0R_COLOR_MODEL_BGRA8888", "group___c_o_l_o_r___m_o_d_e_l.html#ga4ff9ca3b84e5057b0b7aeee176d6d3a3", null ],
    [ "F0R_COLOR_MODEL_PACKED32", "group___c_o_l_o_r___m_o_d_e_l.html#ga42c9b2342651a04a3045b980cf31cf97", null ],
    [ "F0R_COLOR_MODEL_RGBA8888", "group___c_o_l_o_r___m_o_d_e_l.html#ga68d6ca25df33b7759dfb2c2f6b44a229", null ]
];