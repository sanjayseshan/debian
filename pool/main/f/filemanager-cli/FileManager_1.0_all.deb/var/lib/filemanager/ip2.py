import os,time
time.sleep(0.2)
#os.system("python2 /scripts/ip.py &")
#print "x"
#while True:
#        os.system('clear')
x = os.popen('ifconfig | fgrep " add" | fgrep -v 127.0.0.1 | fgrep -v inet6 | awk \'{print $2}\' | awk -F \':\' \'{print $2}\' | xargs echo "My ip address:"').read()
print x
print "Exiting in 3 seconds. --> Please Wait"
time.sleep(0.2)
time.sleep(3)
