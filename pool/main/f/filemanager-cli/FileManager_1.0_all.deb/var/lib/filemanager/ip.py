import sys,tty,termios,time
class _Getch:       
    def __call__(self):
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(sys.stdin.fileno())
                ch = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            return ch

def get():
    inkey = _Getch()
    while(1):
            k=inkey()
            if k!='':break
    print 'you pressed', ord(k)
    return ord(k)
def main():
     x = 0
     while x != 13:
	time.sleep(0.05)
	x = get()
     time.sleep(0.2)
     os.system("killall python2")

if __name__=='__main__':
    main()

